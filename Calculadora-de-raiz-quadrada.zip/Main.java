import java.util.Scanner; 
class Main {
  public static void main(String[] args) {
    Scanner num = new Scanner(System.in);
    int entrada;
    double resultado;
    System.out.println("Digite um número");
    entrada = num.nextInt();
    resultado = Math.sqrt(entrada);
    System.out.println("A raiz quadrade de "+entrada+" é "+resultado);
  }
}